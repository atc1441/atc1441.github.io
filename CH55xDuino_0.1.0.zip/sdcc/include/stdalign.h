#ifndef __SDCC_STDALIGN_H
#define __SDCC_STDALIGN_H 1

#ifndef __alignas_is_defined
#define __alignas_is_defined 1

#define alignas _Alignas

#endif


#ifndef __alignof_is_defined
#define __alignof_is_defined 1

#define alignof _Alignof

#endif

#endif

